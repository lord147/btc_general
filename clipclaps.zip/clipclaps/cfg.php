<?php

/*
PERHATIKAN CARA ADMIN MENGISI DATA!!
SEMUA SUDAH ADA DI VIDIO
*/
$userid = "xxxxx";
$token = "xxxxx";
$uuid = "xxxxx";
/*
USER_AGENT BISA DI CARI DI GOOGLE
DENGAN KATA KUNCI WHAT MY USER AGENT
*/
$user_agent="xxxxx";
