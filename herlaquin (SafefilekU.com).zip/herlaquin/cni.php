<?php
//BOT1 = harlaquin
$user = "zzzzzz";
$cookie = "zzzzzz";

?>
