<?
//LOG IN SEMUA COIN BOSSSHIT
//ALLCOOKIE👇👇
$cookie = "Ref=EC-UserId-75174; PHPSESSID=29a1a4338f39ff4f93da2b7eab4c6cd4; BCNToken=fpe07UbEiaa4Udi6MzKQXBtP4r1pL7x3; DGBToken=sjvcZQf5UZOVqrNbpPNLyrIJondHwtc8; BTTToken=nxSsRi1LHSyBgJcIF0v12uQRzyfoKbAm; PIVXToken=y8pHUKf8UiPpsf0VzU0WusMbtWZpoyID; RVNToken=U2NOgLXo7Fud5oZ6mIanb7bcZj0XpSCA";
//USERAGENT
$user = "Mozilla/5.0 (Linux; Android 8.1.0; CPH1909) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/88.0.4324.152 Mobile Safari/537.36";