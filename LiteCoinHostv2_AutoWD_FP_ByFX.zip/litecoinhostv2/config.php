<?php

// JANGAN MENGUBAH APAPUN SELAIN YG DIDALAM TANDA (")
// PERHATIKAN TANDA (") JANGAN SAMPAI TERHAPUS
// AGAR SCRIPT TIDAK ERROR

$wallet = "Input LTC Wallet Faucetpay Here";

$user = "Input User-agent Here";

$cookie = "Input All Cookie Here";

