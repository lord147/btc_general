<?php

//                __                            _
//               / _| ___  _ __ _ __   ___  ___(_) __ _
//              | |_ / _ \| '__| '_ \ / _ \/ __| |/ _` |
//              |  _| (_) | |  | | | |  __/\__ \ | (_| |
//              |_|  \___/|_|  |_| |_|\___||___/_|\__,_|
//              Config Files - https://www.fornesia.com
//

// user-agent, harus diganti !! samakan dengan user agent di capture
$agent = 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0';

// ganti cookie cloudflare // jika digi nanti ada cloudflarenya 
// buka web di browser tanpa login lalu capture setelah reload cloudflare
// contoh : cf_clearance=aa315614150626dac5914eae40ccb4480e352859-1623315307-0-150; ci_session=329e7c391c5f03fcbdd3044120d3d61993596806; cf_chl_rc_ni=1; cf_chl_prog=a19
$cookie = 'cf_clearance=53d0ce61f1bcee92d3eb4b2f96d35f6cc7d5961d-1624331279-0-150; typography=poppins; version=dark; layout=vertical; headerBg=color_1; primary=color_1; navheaderBg=color_1; sidebarBg=color_1; sidebarStyle=full; sidebarPosition=fixed; headerPosition=fixed; containerLayout=full; direction=ltr; ci_session=d68d6b28b8123703db2ad20e6ed1cef5cd77e97d';



// EX: https://bittether.site/r/63488
// only paste id reff
$reff = '63488';

// setting password web - leave dafault or change
$paswd = 'bittether';