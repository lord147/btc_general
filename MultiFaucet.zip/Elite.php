<?


$host = array();
$cookie = array();


$useragent = "xxxxxxxx";

$host[]="coindashfaucet.xyz";
$cookie[]="xxxxxxxx";
$BITS[]="5000";   //  Minimum 1000 Dash Satoshi = 5000 Bits



$host[]="1bit.ly";
$cookie[]="xxxxxxx";
$BITS[]="1000";   //  Minimum 1 LTC Satoshi = 5 Bits



$host[]="dash-faucet.xyz";
$cookie[]="xxxxxxxx";
$BITS[]="5000";   //  Minimum 1000 Dash Satoshi = 5000 Bits



$host[]="dash-faucet-free.xyz";
$cookie[]="xxxxxxxx";
$BITS[]="1000";   //  Minimum 1 Dash Satoshi = 5 Bits

