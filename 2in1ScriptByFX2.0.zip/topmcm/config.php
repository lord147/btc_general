<?php

// JANGAN MENGUBAH APAPUN KECUALI YG DI DALAM BERTANDA (")

$user = "MasukanUserAgent";

// WEB TOPFAUCET

$cookieTOP = "CookieWebtopfaucet";

// WEB MCM

$cookieMCM = "CookieWebmcmfaucets";

// PILIH YG INGIN DI CLAIM DARI WEB MCMFAUCETS DENGAN
// MENGUBAH ANGKA NOL "0" MENJADI ANGKA SATU "1".

// INGAT SEMAKIN BANYAK YG INGIN KALIAN CLAIM,
// SEMAKIN CEPAT TIMER YG TERKURAS

$TRX = "0";
$BCN = "0";
$ADA = "0";
$DASH = "0";
$DGB = "0";
$DOGE = "0";
$ETC = "0";
$LSK = "0";
$NEO = "0";
$PPC = "0";
$ZEN = "0";
$RDD = "0";
$XRP = "0";
$STRAX = "0";
$XTZ = "0";
$WAVES = "0";
$ZEC = "0";
$EXS = "0";
$EXG = "0";
$PIVX = "0";
$VTC = "0";
$KMD = "0";








