<?php

// Jangan Mengubah Apapun Selain Yg Didalam Tanda Kutip(")
// Perhatikan Tanda Kutip (") Jangan Sampai Terhapus Agar Script Tidak Error

$wallet = 'Masukan Wallet DOGE Disini';

$user = 'Masukan User-Agent Disini';

$cookie = 'Masukan Semua Cookie Disini';



