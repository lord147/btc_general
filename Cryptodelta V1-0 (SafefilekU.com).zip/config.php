<?php


$userAgent = "Mozilla/5.0 (Linux; Android 10; Redmi Note 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.101 Mobile Safari/537.36";

#1 On 0 Off

$BTC="0";
$BCH="0";
$BCN="0";
$ADA="0";
$DASH="0";
$DGB="0";
$DOGE="1";
$ETH="0";
$ETC="0";
$LSK="0";
$LTC="0";
$XMR="1";
$NEO="0";
$PPC="0";
$KMD="0";
$RDD="0";
$XRP="1";
$STRAX="0";
$XTZ="0";
$TRX="1";
$WAVES="1";
$ZEC="1";
$EXS="0";
$EXG="0";
$PIVX="0";
$VTC="0";