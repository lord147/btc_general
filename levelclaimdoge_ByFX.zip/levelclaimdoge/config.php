<?php

// JANGAN MENGUBAH APAPUN SELAIN YG DIDALAM TANDA (")
// PERHATIKAN TANDA (") JANGAN SAMPAI TERHAPUS
// AGAR SCRIPT TIDAK ERROR

$user = "Masukan User-Agent Disini";

$cookie = "Masukan Semua Cookie Disini";




